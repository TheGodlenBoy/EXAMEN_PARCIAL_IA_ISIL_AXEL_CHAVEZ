﻿using UnityEngine;

public class Agent : SBAgent
{
	public Transform points;
	GameManager manager;

	void Start()
	{
		maxSpeed = 0.5f;
		maxSteer = 0.5f;
	
	}

	void Update()
	{
	
		velocity += SteeringBehaviours.Seek(this, points);
		transform.position += velocity;
		

	}
}
