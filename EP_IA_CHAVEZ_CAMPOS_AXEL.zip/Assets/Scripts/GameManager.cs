﻿using UnityEngine;
using System.Collections;
using System.Collections.Generic;

public class GameManager : MonoBehaviour
{
	
    public Transform spawner;

    public GameObject[] points ;
	public Transform[] positionPoints;
    GameObject[] agentsA;
    int contadorA;
    float TimerA;
    float timeSpawnA = 1f;
    GameObject instanceA;

	GameObject[] agentsB;
    int contadorB;
    float TimerB;
    float timeSpawnB = 3f;
    GameObject instanceB;


	//public  GameObject[] target;
	public static List<GameObject> target = new List<GameObject>();




    /* 
        void Start()
        {
            for (int i = 0; i < N; i++)
            {
                GameObject agent = Resources.Load<GameObject>("AgentA");
                GameObject instance = Instantiate(agent);

                if (i == 0)
                {
                    instance.GetComponent<Agent>().target = GameObject.Find("Target").transform;
                }
                else
                {
                    instance.GetComponent<Agent>().target = agents[i - 1].transform;
                }

                instance.transform.position = new Vector3(Random.Range(-5, 5), Random.Range(-5, 5), 0);
                instance.name = "AgentA" + i.ToString();
                agents[i] = instance;
            }
        }
    */

	void Start()
	{
			points = GameObject.FindGameObjectsWithTag("point");

	}

    void Update()
    {
		
            TimerA += Time.deltaTime;
            if (timeSpawnA < TimerA)
            {
                GameObject agentA = Resources.Load<GameObject>("AgentA");
                instanceA = Instantiate(agentA);
                instanceA.transform.position = new Vector3(spawner.transform.position.x, spawner.transform.position.y, 0);
				//print("Agente A [" + (contadorA) + "]  creado");
                instanceA.name = "AgentA " + contadorA.ToString();
                contadorA++;


                TimerA = 0;
            }
        


			     TimerB += Time.deltaTime;
            if (timeSpawnB < TimerB)
            {
                GameObject agentB = Resources.Load<GameObject>("AgentB");
                instanceB = Instantiate(agentB);
                instanceB.transform.position = new Vector3(spawner.transform.position.x, spawner.transform.position.y, 0);
				//print("Agente B [" + (contadorB) + "]  creado");
                instanceB.name = "Agent B " + contadorB.ToString();
                contadorB++;


                TimerB = 0;
            }

  
    }
}
